java -Xms256m -Xmx768m -jar StarZoomAtomiser.jar
wait